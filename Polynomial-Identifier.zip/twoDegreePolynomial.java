//Simpler version of Polynomial
//Can only handle 2 degree polynomials
class twoDegreePolynomial {

  //Global Variables
  double x1;
  double y1;
  double x2;
  double y2;
  double x3;
  double y3;
  String a;
  String b;
  String c;

  //Constructor
  twoDegreePolynomial(double[] p1,double[]p2, double[]p3)
  {
    x1 = p1[0];
    y1 = p1[1];
    x2 = p2[0];
    y2 = p2[1];
    x3 = p3[0];
    y3 = p3[1];

    double tempa = (x1*(y3-y2)+x2*(y1-y3)+x3*(y2-y1))/((x1-x2)*(x1-x3)*(x2-x3));

    a = String.valueOf(tempa);
    
    double tempb = (y2-y1)/(x2-x1) - tempa*(x1+x2);

    b = String.valueOf(tempb);

    double tempc = y1 - tempa*(Math.pow(x1,2))-(tempb*x1);

    c = String.valueOf(tempc);

    if(tempb >= 0)
    {
      b = "+" + b;
    }
    if(tempc >= 0)
    {
      c = "+" + c;
    }
  }

  public void getPolynomial()
  {
    System.out.println(a+"x^2"+b+"x"+c);
  }
  //TEST CODE FOR MAIN CLASS
  /*
    double[] pointOne = new double[] {1,1};
    double[] pointTwo = new double[] {2,2};
    double[] pointThree = new double[] {3,3};

    Polynomial a = new twoDegreePolynomial(pointOne, pointTwo, pointThree);

    a.getPolynomial();
    */
}